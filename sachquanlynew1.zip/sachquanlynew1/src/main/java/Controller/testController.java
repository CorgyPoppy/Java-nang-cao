package Controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class testController
 */
@WebServlet("/testController")
public class testController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public testController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//PrintWriter out= response.getWriter();
		//out.print("<html><body>Alo meophac </body></html>");
		
		//Dieu huong ve file jsp
	//	response.sendRedirect("tc.jsp");
		
		//Tao 1 bien request
		String[] ds= {"Ha", "Nam", "Thanh"};
		request.setAttribute("dsten", ds);
		request.setAttribute("s", (int)10);
		
		//Tao 1 bien session
		HttpSession session = request.getSession();
		session.setAttribute("un", "<hr>"+"Alo");
		//Chuyen tiep ve trang vd5.jsp
		RequestDispatcher rd = request.getRequestDispatcher("vd5.jsp");
		rd.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
