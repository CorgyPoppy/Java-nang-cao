package Controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import nl.captcha.Captcha;

/**
 * Servlet implementation class dangnhapController
 */
@WebServlet("/dangnhapController")
public class dangnhapController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public dangnhapController() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		
		HttpSession session = request.getSession();
		Integer dem = (Integer) session.getAttribute("dem");
		if (dem == null)
			dem = 0;
		
		String un = request.getParameter("txtun");
		String pass = request.getParameter("txtpass");
		
		if (un != null && pass != null) {
			boolean ktraCaptcha = true;
			
			if (dem > 3) {
				Captcha captcha = (Captcha) session.getAttribute(Captcha.NAME);
				String answer = request.getParameter("answer");
				ktraCaptcha = false;
				if (captcha != null) {
					if (answer != null) {
						if (captcha.isCorrect(answer)) {
							ktraCaptcha=  true;
						}
					}
				}
			}
			if (ktraCaptcha == true && un.equals("abc") && pass.equals("123")) {
				session.removeAttribute("dem");
				session.setAttribute("un", un);
				response.sendRedirect("tcController");
				return;
			}
				dem++;
				session.setAttribute("dem", dem);
				request.setAttribute("tb", 1);
		}	 
		if (dem > 3) request.setAttribute("hiencaptcha", true);
		request.getRequestDispatcher("dangnhap.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
