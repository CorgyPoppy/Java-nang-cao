<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link
	href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css"
	rel="stylesheet">
<link href="https://getbootstrap.com/docs/5.3/assets/css/docs.css"
	rel="stylesheet">
<title>Bootstrap Example</title>
<script defer
	src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body class="p-3 m-0 border-0 bd-example m-0 border-0">
	<!-- Example Code Start-->
	<nav class="navbar navbar-expand-lg bg-body-tertiary">
		<div class="container-fluid">
			<button class="navbar-toggler" type="button"
				data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent"
				aria-controls="navbarSupportedContent" aria-expanded="false"
				aria-label="Toggle navigation">
				<span class="navbar-toggler-icon"></span>
			</button>
			<div class="collapse navbar-collapse" id="navbarSupportedContent">
				<ul class="navbar-nav me-auto mb-2 mb-lg-0">
					<li class="nav-item"><a class="nav-link active"
						aria-current="page" href="tcController">Trang chủ</a></li>
					<li class="nav-item"><a class="nav-link" href="#">Giỏ hàng</a>
					</li>
					<li class="nav-item"><a class="nav-link" href="#">Thanh
							toán</a></li>
					<li class="nav-item"><a class="nav-link" href="#">Lịch sử
							mua hàng</a></li>
					<li class="nav-item"><a class="nav-link" href="dangnhapController">Đăng
							nhập</a></li>
					<li class="nav-item"><a class="nav-link" href="dangxuatController">Đăng
							xuất</a></li>
					<li class="nav-item"><a class="nav-link disabled"
						aria-disabled="true">Disabled</a></li>
				</ul>

				<form class="d-flex" role="search">
					<input class="form-control me-2" type="search" placeholder="Search"
						aria-label="Search">
					<button class="btn btn-outline-success" type="submit">Search</button>
				</form>
			</div>
		</div>
	</nav>
	<!-- Example Code End -->
	<form action="dangnhapController" method="post">
		Ten tai khoan: <input type="text" name="txtun"><br> Mat
		khau: <input type="password" name="txtpass"><br>
	<% if (request.getAttribute("hiencaptcha") != null) { %>
	<img src="simpleCaptcha.jpg" width="150"><br> 
	Nhap ma: <input type="text" name="answer"><br>
	<% } %>

	<input type="submit" value="login">
	</form>

	<% if (request.getAttribute("tb") != null) { %>
	dang nhap sai
	<% } %>
</body>
</html>