<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<!DOCTYPE html>
<%
    String user = request.getParameter("username");
    String pass = request.getParameter("password");
%>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Insert title here</title>
</head>
<body>
<%
    if(user.equals("abc") && pass.equals("123")){
%>
        
<%
    } else {
%>
        <h2>Sai tai khoan hoac mat khau!</h2>
        <a href="login.jsp">Quay lai dang nhap</a>
<%
    }
%>
</body>
</html>