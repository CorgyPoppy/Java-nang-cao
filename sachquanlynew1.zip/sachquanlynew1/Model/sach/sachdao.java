package sach;

import java.util.ArrayList;

public class sachdao {
	public ArrayList<sach> getSach() throws Exception{
		ArrayList<sach> ds =new ArrayList<sach>();
		ds.add(new sach("s1","CSDL","Hưng",(long)10000,(long)3,"b1.jpg","l1"));
		ds.add(new sach("s2","CSDL1","Thủy",(long)20000,(long)3,"b2.jpg","l1"));
		ds.add(new sach("s3","CSDL2","Huy",(long)30000,(long)3,"b3.jpg","l1"));
		ds.add(new sach("s4","CSDL3","Loan",(long)40000,(long)3,"b4.jpg","l2"));
		ds.add(new sach("s5","CSDL4","Trung",(long)50000,(long)3,"b5.jpg","l2"));
		ds.add(new sach("s6","CSDL5","Nam",(long)60000,(long)3,"b6.jpg","l2"));
		return ds;
	}
}
