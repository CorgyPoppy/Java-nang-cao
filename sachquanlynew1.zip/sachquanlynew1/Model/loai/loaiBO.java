package loai;

import java.util.ArrayList;

public class loaiBO {
	loaidao ldao=new loaidao();
	public ArrayList<loai> getloai() throws Exception {
		return ldao.getloai();
	}
}
