package loai;

public class loai {
	private String maloai;
	private String tenloai;
	
	public loai(String maloai, String tenloai) { // phat sinh ham tao co tham so
		super();
		this.maloai = maloai;
		this.tenloai = tenloai;
	}
	public loai() { // phat sinh ham tao ko tham so
		super();
		// TODO Auto-generated constructor stub
	}
	public String getMaloai() {
		return maloai;
	}
	public void setMaloai(String maloai) {
		this.maloai = maloai;
	}
	public String getTenloai() {
		return tenloai;
	}
	public void setTenloai(String tenloai) {
		this.tenloai = tenloai;
	}
}
